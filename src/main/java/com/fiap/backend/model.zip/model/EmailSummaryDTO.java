package com.fiap.backend.model;

import jakarta.persistence.Column;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@Getter
@Setter
public class EmailSummaryDTO {
    private String from;
    private Date date;
    private String subject;

    private String groupName;
    private String color;

    public EmailSummaryDTO(String from, Date date, String subject) {
        this.from = from;
        this.date = date;
        this.subject = subject;
    }

}
