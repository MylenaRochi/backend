package com.fiap.backend.entities;

import jakarta.persistence.*;

import java.util.List;
import java.util.UUID;

@Entity
@Table(name = "email_groups")
public class EmailGroup {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private UUID id;

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @Column(nullable = false)
    private String groupName;

    @Column(nullable = false)
    private String color;

    @ElementCollection
    private List<String> filterBy;  // Lista de palavras para filtrar os e-mails

    @Column(nullable = false)
    private Boolean notificate;

}
