package com.fiap.backend.entities;

public enum EmailType {

    OUTLOOK,
    GMAIL
}
